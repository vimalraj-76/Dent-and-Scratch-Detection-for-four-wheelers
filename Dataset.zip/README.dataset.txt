# car dent detection > 2022-10-09 6:18pm
https://universe.roboflow.com/object-detection/car-dent-detection-eerqw

Provided by Roboflow
License: CC BY 4.0

